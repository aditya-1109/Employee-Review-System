import express, { urlencoded } from "express";
import path from "path";
import ejsLayouts from "express-ejs-layouts";
import { usercontroller } from "./src/controller/user.controller.js";
import { employeeController } from "./src/controller/employee.controller.js";
import { reviewController } from "./src/controller/review.controller.js";
import mongoose from "mongoose";
import { employeeViewController } from "./src/controller/employeesView.controller.js";
import session from "express-session";
import { authassign, authadmin, authemployee } from "./src/middleware/auth.js";

const server= express();

const dbConnect=mongoose.connect("mongodb://localhost:27017/employees");

server.set("view engine", "ejs");
server.set("views", path.join(path.resolve(),"src", "view" ));
server.use(ejsLayouts);

server.use(session({
    secret: "secretKey",
    resave: false,
    saveUninitialized: true,
    cookie:{secure:false},
}));

server.use(express.urlencoded({extended: false}));
server.set(express.static("/src/view"));

server.get("/",usercontroller.getRegister);
server.post("/",usercontroller.postRegister);

server.get("/login", usercontroller.getLogin);
server.post("/login", usercontroller.postLogin);

server.get("/employee",authadmin,employeeController.getEmployee);

server.get("/addEmployee",authadmin, employeeController.getAddEmployee);
server.post("/addEmployee", employeeController.postAddEmployee);

server.get("/updateEmployee/:id",authadmin, employeeController.updateEmployee);
server.post("/updateEmployee/:id", employeeController.PostUpdateEmployee);

server.get("/remove/:id",authadmin, employeeController.getRemove);

server.get("/review/:id", authadmin,reviewController.getReview);
server.get("/addReview/:id",authassign, reviewController.getAddreview);
server.post("/addReview/:id", reviewController.postAddreview);

server.get("/update/:id",authadmin, reviewController.updateReview);
server.post("/update/:id", reviewController.PostUpdateReview);

server.get("/assign/:id",authadmin, reviewController.getAssignReview);
server.post("/assign/:id", reviewController.postAssignReview);

server.get("/employeeView",authemployee, employeeViewController.getEmployeeView);

server.get("/feedback/:type/:id",authemployee,employeeViewController.getFeedback);
server.post("/feedback/:type/:id", employeeViewController.postFeedback);

server.get("/logout", usercontroller.logout);

server.listen(3000,()=>{
    dbConnect;
    console.log("server is listening at 3000");
});