import mongoose from "mongoose";

const employeeSchema=new mongoose.Schema({
    name: {type: String, required:true},
    id: {type: Number, required: true},
    post: {type: String, required: true},
});

export const employeeModel=mongoose.model("employee", employeeSchema);