import mongoose from "mongoose";

const reviewSchema= new mongoose.Schema({
    id:{type:Number},
    attendence:{type:Number,min:0, max:10},
    attendenceFeedback:{type:Boolean},
    innovation:{type: Number,min:0, max:10},
    innovationFeedback:{type:Boolean},
    leadership:{type:Number,min:0, max:10},
    leadershipFeedback:{type:Boolean},
    skill:{type:Number,min:0, max:10},
    skillFeedback:{type:Boolean},
    teamwork:{type:Number,min:0, max:10},
    teamworkFeedback:{type:Boolean},
    management:{type:Number,min:0, max:10},
    managementFeedback:{type:Boolean},
    problem:{type:Number,min:0, max:10},
    problemFeedback:{type:Boolean},
    experience:{type:Number,min:0, max:10},
    experienceFeedback:{type:Boolean},
    ethics:{type:Number,min:0, max:10},
    ethicsFeedback:{type:Boolean},
});

export const reviewModel=mongoose.model("review", reviewSchema);

const assignedReviewSchema= new mongoose.Schema({
    name:{type:String},
    id:{type:Number},
    otherName:{type:String,required:true},
    otherId:{type:Number, required:true},
    link:{type:String},
});

export const assignedModel=mongoose.model("assigned", assignedReviewSchema);