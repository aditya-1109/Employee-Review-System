import mongoose from "mongoose";

const feedbackSchema= new mongoose.Schema({
    id:{type:Number},
    attendance:{type:String},
    innovation:{type:String},
    leadership:{type:String},
    skill:{type:String},
    teamwork:{type:String},
    management:{type:String},
    problem:{type:String},
    experience:{type:String},
    ethics:{type:String},
})

export const feedbackModel= mongoose.model("feedback",feedbackSchema);