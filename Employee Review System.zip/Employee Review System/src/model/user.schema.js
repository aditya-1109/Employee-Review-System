import mongoose from "mongoose";

const userSchema=new mongoose.Schema({
    name:{type:String, required: true},
    id:{type: Number, required: true},
    email: {
        type: String,
        required: true,
        unique: true,
        validate: {
          validator: function (value) {
            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
          },
          message: 'Invalid email address format',
        },
      },
    password:{type: String,minlength:8, required: true},
    userType:{type:String},
});

export const usermodel= mongoose.model("user", userSchema);