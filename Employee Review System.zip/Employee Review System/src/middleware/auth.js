export const authemployee=(req,res,next)=>{
    if(req.session.type=="employee"){
        next()
    }else{
        res.redirect("/login");
    }
}

export const authadmin=(req,res,next)=>{
    if(req.session.type=="admin"){
        next()
    }else{
        res.redirect("/login");
    }
}

export const authassign=(req,res,next)=>{
    if(req.session.type=="admin"  || req.session.otherid==req.session.myId){
        next()
    }else{
        res.redirect("/login");
    }
}