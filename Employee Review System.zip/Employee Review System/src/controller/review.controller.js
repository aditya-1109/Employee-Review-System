import { employeeModel } from "../model/employee.schema.js";
import { assignedModel, reviewModel } from "../model/review.schema.js";

export class reviewController{
    static getReview=async(req, res)=>{
        const {id}=req.params;
        const review= await reviewModel.find({"id":id});
        if(review){
        res.render("review", {reviews:review, id:id, type: req.session.type});
        }else{
            res.status(401).send("could not find review");
        }

    }

    static getAddreview=(req, res)=>{
        const {id}=req.params;
        res.render("addReview", {id:id, type: req.session.type});
    }

    static postAddreview=async(req, res)=>{
        const {id}=req.params;
        try{
        const review= new reviewModel(req.body);
        review.id=id;
        await review.save();
        res.redirect("/review/"+id);
        }catch(err){
            res.status(401).send("could not create review");
        }
    }

    static updateReview=(req,res)=>{
        const {id}=req.params;
        res.render("addReview",{id:id, type: req.session.type});
    }

    static PostUpdateReview=async(req,res)=>{
        const {id}=req.params;
        const review=await reviewModel.findOneAndUpdate({"id":id},req.body, {new:true});
        if(review){
        res.redirect("/review/"+id);
        }else{
            res.status(401).send("could not update");
        }
    }

    static getAssignReview=(req, res)=>{
        res.render("assignReview",{type: req.session.type});
    }

    static postAssignReview=async(req,res)=>{
        const {id}=req.params;
        const link="/addReview/"+id;
        const employee=await employeeModel.findOne({"id":id});
        if(employee){
        const name= employee.name;
        try{
        const assignedReview= new assignedModel(req.body);
        assignedReview.name= name;
        assignedReview.id=id;
        assignedReview.link=link;
        await assignedReview.save();
        const {otherId}=req.body;
        req.session.otherid=otherId;
        res.redirect("/employee");
        }catch{
            res.status(401).send("cannot assign to this ID");
        }
        }else{
            res.status(401).send("cannot assign review");
        }
    }
}