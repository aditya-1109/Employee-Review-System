import { feedbackModel } from "../model/feedback.js";
import { assignedModel, reviewModel } from "../model/review.schema.js";

export class employeeViewController{
    static getEmployeeView=async(req,res)=>{
        const id=req.session.myId;
        console.log(id);
        const review=await reviewModel.findOne({"id":id});
        if(review){
                const assignReview=await assignedModel.findOne({"otherId":id});
                if(assignReview){
                res.render("employeeView",{review:review, assignReview: assignReview, type: req.session.type});
            }else{
                const assignReview="";
                res.render("employeeView",{review:review, assignReview: assignReview, type: req.session.type});
            }
        }else{
            const assignReview=await assignedModel.findOne({"otherId":id});
            if(assignReview){
                const review="";
            res.render("employeeView",{review:review, assignReview: assignReview, type: req.session.type});
            }else{
            const review="";
            const assignReview="";
            res.render("employeeView",{review:review, assignReview: assignReview, type: req.session.type});
        }
        }
        
    }

    static getFeedback=(req,res)=>{
        const {types}=req.params;
        res.render("feedback", {"types":types, type: req.session.type});
    }

    static postFeedback=async(req,res)=>{
        const {id}=req.params;
        try{
        const feedback= new feedbackModel(req.body);
        feedback.id=id;
        await feedback.save();
        res.redirect("/employeeView");
        }catch(err){
            res.status(401).send("could not submit feedback");
        }
    }
}