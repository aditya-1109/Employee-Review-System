import { employeeModel } from "../model/employee.schema.js";

export class employeeController{
    static getEmployee=async(req, res)=>{
        const employees=await employeeModel.find();
        res.render("adminView",{employees: employees, type: req.session.type});
    }

    static getAddEmployee=(req, res)=>{
        const id="";
        res.render("addEmployee", {id:id, type: req.session.type});
    }

    static postAddEmployee=async(req,res)=>{
        try{
        const employee= new employeeModel(req.body);
        await employee.save();
        res.redirect("/employee");
        }catch(err){
            res.status(401).send("Could not create employee");
        }
    }

    static getRemove=async(req,res)=>{
        const {id}= req.params;
        try{
        const employee=await employeeModel.deleteOne({"id":id});
        res.redirect("/employee");
        }catch(err){
            res.status(401).send("could not delete");
        }
    }

    static updateEmployee=(req,res)=>{
        const {id}=req.params;
        res.render("addEmployee",{id:id, type: req.session.type});
    }

    static PostUpdateEmployee=async(req,res)=>{
        const {id}=req.params;
        const employee=await employeeModel.findOneAndUpdate({"id":id},req.body,{new:true});
        if(employee){
        res.redirect("/employee");
        }else{
            res.status(401).send("could not Update");
        }
    }
}