import { usermodel } from "../model/user.schema.js";

export class usercontroller{
    static getRegister=(req, res)=>{
        const errormsg= "";
        res.render("register",{errormsg: errormsg, type: req.session.type})
    }

    static postRegister=async(req,res)=>{
        try{
        const user=new usermodel(req.body);
        await user.save();
        res.redirect("/login");
        }catch(err){
            res.status(401).send("Please enter the correct syntax");
        }
    }

    static getLogin=(req, res)=>{
        const message="";
        res.render("login",{message:message, type: req.session.type});
    }

    static postLogin=async(req,res)=>{
        const {id, password}= req.body;
        const user= await usermodel.findOne({"id":id});
        if(user){
            if(!user.password==password){
                res.status(401).send("invalid user");
            }
            else{
                req.session.myId=id;
                if(user.userType=="employee"){
                    req.session.type="employee";
                    res.redirect("/employeeView");
                }else{
                    req.session.type="admin";
                    res.redirect("/employee");
                }
            }
        }
        else{
            res.status(401).send("invalid user");
        }
    }

    static logout=async(req,res)=>{
        req.session.destroy((err)=>{
            if(err){
                res.status(401).send("invalid logout");
            }else{
                res.redirect("/login");
            }
        })
    }
}